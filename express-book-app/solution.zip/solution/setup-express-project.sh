mkdir express-book-app
cd express-book-app
npm init -y
npm i express
touch index.js
node index.js
npm i -D nodemon
npm i uuid
mkdir routes
cd routes
touch books.js
touch login.js
npm i jsonwebtoken
npm i dotenv
npm i @sentry/node

