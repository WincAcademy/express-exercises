npm i prisma -D
npx prisma init
npx prisma format .
npx prisma db push
npm install @prisma/client
npx prisma generate
npx prisma db seed
npx prisma studio
npm run dev
npx prisma migrate dev --name init
npx prisma migrate reset --skip-seed
