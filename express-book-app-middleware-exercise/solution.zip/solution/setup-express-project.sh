mkdir express-book-app
cd express-book-app
npm init -y
npm install express
touch index.js
node index.js
npm i -D nodemon
npm i uuid
mkdir routes
cd routes
touch books.js
